Programming Language: Python version 3.11.0
Used Libraries: Flask 2.2.2
                Numpy 1.23.4
                Matplotlib 3.6.2

To run the program : python web.py